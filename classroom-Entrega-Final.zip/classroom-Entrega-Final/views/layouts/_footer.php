<!-- Main Footer -->
<footer class="main-footer">
    <div class="container">
        <div class="row">
            <!-- To the right -->
            <div class="col-md12 text-md-end">
                <p> Copyright &copy; 2024 Proyecto integrador@ - Todos los derechos reservados</p>
            </div>
            <!-- Default to the left -->
        </div>
    </div>
</footer>
